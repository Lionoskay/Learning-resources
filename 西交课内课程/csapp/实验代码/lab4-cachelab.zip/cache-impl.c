#include "cachelab.h"
#include <stdint.h>
#include <stdbool.h>

int l1d_hits = 0;
int l1d_misses = 0;
int l1d_evictions = 0;
int l1i_hits = 0;
int l1i_misses = 0;
int l1i_evictions = 0;
int l2_hits = 0;
int l2_misses = 0;
int l2_evictions = 0;
int l3_hits = 0;
int l3_misses = 0;
int l3_evictions = 0;

// 全局时钟，用于LRU替换策略
static uint64_t clock_time = 0;

// 你可以添加自己的数据结构和函数

// 初始化cache
void cacheInit() {
  // 初始化 L1D cache
  for (int set = 0; set < L1_SET_NUM; set++) {
    for (int way = 0; way < L1_LINE_NUM; way++) {
      l1dcache[set][way].valid = 0;
      l1dcache[set][way].dirty = 0;
      l1dcache[set][way].tag = 0;
      l1dcache[set][way].latest_used = 0;
    }
  }
  
  // 初始化 L1I cache
  for (int set = 0; set < L1_SET_NUM; set++) {
    for (int way = 0; way < L1_LINE_NUM; way++) {
      l1icache[set][way].valid = 0;
      l1icache[set][way].dirty = 0;
      l1icache[set][way].tag = 0;
      l1icache[set][way].latest_used = 0;
    }
  }
  
  // 初始化 L2 cache
  for (int set = 0; set < L2_SET_NUM; set++) {
    for (int way = 0; way < L2_LINE_NUM; way++) {
      l2ucache[set][way].valid = 0;
      l2ucache[set][way].dirty = 0;
      l2ucache[set][way].tag = 0;
      l2ucache[set][way].latest_used = 0;
    }
  }
  
  // 初始化 L3 cache
  for (int set = 0; set < L3_SET_NUM; set++) {
    for (int way = 0; way < L3_LINE_NUM; way++) {
      l3ucache[set][way].valid = 0;
      l3ucache[set][way].dirty = 0;
      l3ucache[set][way].tag = 0;
      l3ucache[set][way].latest_used = 0;
    }
  }
}

// 找到LRU替换的cache line索引
int findLRUWay(CacheLine *lines, int size) {
  int lru_way = 0;
  uint64_t min_time = lines[0].latest_used;

  for (int i = 1; i < size; i++) {
    if (lines[i].latest_used < min_time) {
      min_time = lines[i].latest_used;
      lru_way = i;
    }
  }
  
  return lru_way;
}

// 找到空闲的或需要替换的cache line索引
int findReplaceWay(CacheLine *lines, int size) {
  // 首先查找无效的cache line
  for (int i = 0; i < size; i++) {
    if (!lines[i].valid) {
      return i;
    }
  }
  
  // 如果没有无效的cache line，使用LRU替换
  return findLRUWay(lines, size);
}

// 从地址中提取L1 cache相关信息
void getL1AddressInfo(uint64_t addr, uint64_t *tag, uint64_t *set) {
  *set = (addr >> 3) & 0x3; // 2位，取bit 3-4
  *tag = addr >> 5;         // 取bit 5及以上
}

// 从地址中提取L2 cache相关信息
void getL2AddressInfo(uint64_t addr, uint64_t *tag, uint64_t *set) {
  *set = (addr >> 3) & 0x7; // 3位，取bit 3-5
  *tag = addr >> 6;         // 取bit 6及以上
}

// 从地址中提取L3 cache相关信息
void getL3AddressInfo(uint64_t addr, uint64_t *tag, uint64_t *set) {
  *set = (addr >> 4) & 0xF; // 4位，取bit 4-7
  *tag = addr >> 8;         // 取bit 8及以上
}

// 构建内存地址
uint64_t buildAddressL1(uint64_t tag, uint64_t set) {
  return (tag << 5) | (set << 3);
}

uint64_t buildAddressL2(uint64_t tag, uint64_t set) {
  return (tag << 6) | (set << 3);
}

uint64_t buildAddressL3(uint64_t tag, uint64_t set) {
  return (tag << 8) | (set << 4);
}

// back invalidation函数，处理inclusive policy要求
void backInvalidate(uint64_t addr, char type) {
  uint64_t l1_tag, l1_set;
  uint64_t l2_tag, l2_set;
  
  getL1AddressInfo(addr, &l1_tag, &l1_set);
  getL2AddressInfo(addr, &l2_tag, &l2_set);
  
  // 如果是L3驱逐影响L2
  if (type == '3') {
    // 检查并无效化L2中的对应行
    for (int i = 0; i < L2_LINE_NUM; i++) {
      if (l2ucache[l2_set][i].valid && l2ucache[l2_set][i].tag == l2_tag) {
        // 如果是dirty的，需要写回L3（但此时L3可能已经被替换）
        // 所以在实际硬件中可能会直接写回内存，但我们这里简化处理
        l2ucache[l2_set][i].valid = 0;
        
        // 递归处理L1
        backInvalidate(buildAddressL2(l2_tag, l2_set), '2');
      }
    }
  }
  // 如果是L2驱逐影响L1
  else if (type == '2') {
    // 检查并无效化L1D中的对应行
    for (int i = 0; i < L1_LINE_NUM; i++) {
      if (l1dcache[l1_set][i].valid && l1dcache[l1_set][i].tag == l1_tag) {
        l1dcache[l1_set][i].valid = 0;
      }
    }
    
    // 检查并无效化L1I中的对应行
    for (int i = 0; i < L1_LINE_NUM; i++) {
      if (l1icache[l1_set][i].valid && l1icache[l1_set][i].tag == l1_tag) {
        l1icache[l1_set][i].valid = 0;
      }
    }
  }
}

// 访问L3 cache的函数
bool accessL3Cache(uint64_t addr, bool is_write) {
  uint64_t tag, set;
  getL3AddressInfo(addr, &tag, &set);
  
  // 检查是否命中
  for (int i = 0; i < L3_LINE_NUM; i++) {
    if (l3ucache[set][i].valid && l3ucache[set][i].tag == tag) {
      // L3 cache命中
      l3_hits++;
      l3ucache[set][i].latest_used = ++clock_time;
      
      if (is_write) {
        l3ucache[set][i].dirty = 1;
      }
      
      return true;
    }
  }
  
  // L3 cache未命中
  l3_misses++;
  
  // 从内存中加载数据
  int way = findReplaceWay(l3ucache[set], L3_LINE_NUM);
  
  // 如果需要替换的cache line是有效的
  if (l3ucache[set][way].valid) {
    // 如果是dirty的，需要写回内存（实际上不需要实现）
    
    // 需要进行back invalidation
    uint64_t evicted_addr = buildAddressL3(l3ucache[set][way].tag, set);
    backInvalidate(evicted_addr, '3');
    
    // 记录eviction
    l3_evictions++;
  }
  
  // 加载新数据
  l3ucache[set][way].valid = 1;
  l3ucache[set][way].dirty = is_write ? 1 : 0;
  l3ucache[set][way].tag = tag;
  l3ucache[set][way].latest_used = ++clock_time;
  
  return false;
}

// 访问L2 cache的函数
bool accessL2Cache(uint64_t addr, bool is_write) {
  uint64_t tag, set;
  getL2AddressInfo(addr, &tag, &set);
  
  // 检查是否命中
  for (int i = 0; i < L2_LINE_NUM; i++) {
    if (l2ucache[set][i].valid && l2ucache[set][i].tag == tag) {
      // L2 cache命中
      l2_hits++;
      l2ucache[set][i].latest_used = ++clock_time;
      
      if (is_write) {
        l2ucache[set][i].dirty = 1;
      }
      
      return true;
    }
  }
  
  // L2 cache未命中
  l2_misses++;
  
  // 从L3中加载数据
  accessL3Cache(addr, false);
  
  // 在L2中找一个位置放置新数据
  int way = findReplaceWay(l2ucache[set], L2_LINE_NUM);
  
  // 如果需要替换的cache line是有效的
  if (l2ucache[set][way].valid) {
    // 如果是dirty的，需要写回L3
    if (l2ucache[set][way].dirty) {
      uint64_t write_back_addr = buildAddressL2(l2ucache[set][way].tag, set);
      accessL3Cache(write_back_addr, true);
    }
    
    // 需要进行back invalidation
    uint64_t evicted_addr = buildAddressL2(l2ucache[set][way].tag, set);
    backInvalidate(evicted_addr, '2');
    
    // 记录eviction
    l2_evictions++;
  }
  
  // 加载新数据
  l2ucache[set][way].valid = 1;
  l2ucache[set][way].dirty = is_write ? 1 : 0;
  l2ucache[set][way].tag = tag;
  l2ucache[set][way].latest_used = ++clock_time;
  
  return false;
}

// 访问L1D cache的函数
bool accessL1DCache(uint64_t addr, bool is_write) {
  uint64_t tag, set;
  getL1AddressInfo(addr, &tag, &set);
  
  // 检查是否命中
  for (int i = 0; i < L1_LINE_NUM; i++) {
    if (l1dcache[set][i].valid && l1dcache[set][i].tag == tag) {
      // L1D cache命中
      l1d_hits++;
      l1dcache[set][i].latest_used = ++clock_time;
      
      if (is_write) {
        l1dcache[set][i].dirty = 1;
      }
      
      return true;
    }
  }
  
  // L1D cache未命中
  l1d_misses++;
  
  // 从L2中加载数据
  accessL2Cache(addr, false);
  
  // 在L1D中找一个位置放置新数据
  int way = findReplaceWay(l1dcache[set], L1_LINE_NUM);
  
  // 如果需要替换的cache line是有效的
  if (l1dcache[set][way].valid) {
    // 如果是dirty的，需要写回L2
    if (l1dcache[set][way].dirty) {
      uint64_t write_back_addr = buildAddressL1(l1dcache[set][way].tag, set);
      accessL2Cache(write_back_addr, true);
    }
    
    // 记录eviction
    l1d_evictions++;
  }
  
  // 加载新数据
  l1dcache[set][way].valid = 1;
  l1dcache[set][way].dirty = is_write ? 1 : 0;
  l1dcache[set][way].tag = tag;
  l1dcache[set][way].latest_used = ++clock_time;
  
  return false;
}

// 访问L1I cache的函数
bool accessL1ICache(uint64_t addr) {
  uint64_t tag, set;
  getL1AddressInfo(addr, &tag, &set);
  
  // 检查是否命中
  for (int i = 0; i < L1_LINE_NUM; i++) {
    if (l1icache[set][i].valid && l1icache[set][i].tag == tag) {
      // L1I cache命中
      l1i_hits++;
      l1icache[set][i].latest_used = ++clock_time;
      return true;
    }
  }
  
  // L1I cache未命中
  l1i_misses++;
  
  // 从L2中加载数据
  accessL2Cache(addr, false);
  
  // 在L1I中找一个位置放置新数据
  int way = findReplaceWay(l1icache[set], L1_LINE_NUM);
  
  // 如果需要替换的cache line是有效的
  if (l1icache[set][way].valid) {
    // L1I应该总是clean的，不需要写回
    // 记录eviction
    l1i_evictions++;
  }
  
  // 加载新数据
  l1icache[set][way].valid = 1;
  l1icache[set][way].dirty = 0; // 指令cache永远不会脏
  l1icache[set][way].tag = tag;
  l1icache[set][way].latest_used = ++clock_time;
  
  return false;
}

// 主要的cache访问函数
void cacheAccess(char op, uint64_t addr, uint32_t len) {
  // 根据操作类型访问不同的cache
  switch(op) {
    case 'I': // 指令读取
      accessL1ICache(addr);
      break;
      
    case 'L': // 数据读取
      accessL1DCache(addr, false);
      break;
      
    case 'S': // 数据存储
      accessL1DCache(addr, true);
      break;
      
    case 'M': // 数据修改（读+写）
      accessL1DCache(addr, false); // 先读
      accessL1DCache(addr, true);  // 再写
      break;
      
    default:
      // 不应该到达这里
      break;
  }
}

