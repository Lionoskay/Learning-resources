#include "poly.h"
#include <sys/time.h>
#include <stdio.h>
void poly_optim(const double a[], double x, long degree, double *result) {
    long i;
    double t[10]={0};
    double pow[11]={1};
    
    for(int j=0;j<10;j++)//初始化r
    {
            t[j]=a[degree-j];//r[0]=a[degree],r[1]=a[degree-1]......
    }
    for(int j=1;j<11;j++)//初始化x的j次幂
    { 
            pow[j]=pow[j-1]*x;
    }
    for(i=degree-10;i>=10;i-=10)//隔十个,同时使得除不尽的时候分配,即剩下最后一组放到后面处理
    {
        t[0] = a[i] + t[0] * pow[10];
        t[1] = a[i - 1] + t[1] * pow[10];
        t[2] = a[i - 2] + t[2] * pow[10];
        t[3] = a[i - 3] + t[3] * pow[10];
        t[4] = a[i - 4] + t[4] * pow[10];
        t[5] = a[i - 5] + t[5] * pow[10];
        t[6] = a[i - 6] + t[6] * pow[10];
        t[7] = a[i - 7] + t[7] * pow[10];
        t[8] = a[i - 8] + t[8] * pow[10];
        t[9] = a[i - 9] + t[9] * pow[10];
    }
    
    //分配x时，依照degree%10来分配，从最高位开始依次乘以x的degree%10次方递减
    double left=0;
    int remain = degree%10;//degree求余
    //初始化分配x平方次数数组
    for(int j=0;j<=remain;j++)
    {
        left=left+a[j]*pow[j];
    }
    double sum=0;
    for(int j=0;j<10;j++)
    {
        t[9-j]=t[9-j]*pow[remain+1]*pow[j];
        sum+=t[9-j];
    }
    *result=left+sum;
    }



void measure_time(poly_func_t poly, const double a[], double x, long degree,
                  double *time) {
    // your code here
    double time_used=0;
    struct timeval start, end;
    for(int i=0;i<3;i++)
    {
    gettimeofday(&start, NULL);
    double result;
    poly(a,x,degree,&result);
    gettimeofday(&end, NULL);
    time_used += (end.tv_sec - start.tv_sec) * 1000000000 + (end.tv_usec - start.tv_usec)*1000;
    }
    double ave_time=0;
    ave_time=time_used/3;
    *time=ave_time;
}