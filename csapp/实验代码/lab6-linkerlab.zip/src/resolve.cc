#include "resolve.h"
#include <iostream>

#define FOUND_ALL_DEF 0
#define MULTI_DEF 1
#define NO_DEF 2

std::string errSymName;

int callResolveSymbols(std::vector<ObjectFile> &allObjects);

void resolveSymbols(std::vector<ObjectFile> &allObjects) {
    int ret = callResolveSymbols(allObjects);
    if (ret == MULTI_DEF) {
        std::cerr << "multiple definition for symbol " << errSymName << std::endl;
        abort();
    } else if (ret == NO_DEF) {
        std::cerr << "undefined reference for symbol " << errSymName << std::endl;
        abort();
    }
}

/* bind each undefined reference (reloc entry) to the exact valid symbol table entry
 * Throw correct errors when a reference is not bound to definition,
 * or there is more than one definition.
 */
int callResolveSymbols(std::vector<ObjectFile> &allObjects)
{
    /* Your code here */
    // if found multiple definition, set the errSymName to problematic symbol name and return MULTIDEF;
    // if no definition is found, set the errSymName to problematic symbol name and return NODEF;

    //处理NODEF
    
    for(auto &obj : allObjects)//遍历每一个object
    {
        for(auto &re : obj.relocTable)//遍历每一个relocentry
        {
            const std::string& symName = re.name;
            std::vector<Symbol*>strongdef;//强符号集合
            std::vector<Symbol*>weakdef;//弱符号集合
            for(auto &otherobj : allObjects)//遍历所有文件
            {
                for(auto &sym : otherobj.symbolTable)//遍历所有符号表
                {
                    if(re.sym==NULL)
                    {
                        return NO_DEF;
                    }
                    bool isStrong;
                    isStrong=(re.sym->name == sym.name && sym.bind == STB_GLOBAL && sym.index != SHN_COMMON && sym.index != SHN_UNDEF);
                    bool isWeak;
                    isWeak=(re.sym->name == sym.name && sym.bind == STB_GLOBAL && sym.index == SHN_COMMON);
                    if(isStrong)
                    {
                        strongdef.push_back(&sym);
                    }
                    else if(isWeak)
                    {
                        weakdef.push_back(&sym);
                    }
                }
            }//先收集满足条件的符号入表再进行判断

            if(strongdef.size()>1)//若强符号集合中元素个数超过1，则报错
            {
                errSymName=symName;
                return MULTI_DEF;
            }
            if (strongdef.empty() && weakdef.empty()) {
                errSymName = symName;
                return NO_DEF; // 立即返回未定义错误（关键！）
            }
            
        }
    }
    
    return FOUND_ALL_DEF;
}
// if(!strongdef.empty())//若强符号非空
            // {
            //     re.sym=strongdef[0];//绑定第一个强符号
            // }
            // else if(!weakdef.empty())//若强符号为空而弱符号非空
            // {
            //     int min=0;
            //     int max=weakdef.size()-1;
            //     int random_num = min + rand() % (max - min + 1);
            //     re.sym=weakdef[random_num];//随机绑定一个弱符号
            // }