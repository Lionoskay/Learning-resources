#pragma once

#include "util.h"

void handleRela(std::vector<ObjectFile> &allObject, ObjectFile &mergedObject, bool isPIE);