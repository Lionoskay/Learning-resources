#include "relocation.h"
#include<iostream>
#include <sys/mman.h>

void handleRela(std::vector<ObjectFile> &allObject, ObjectFile &mergedObject, bool isPIE)
{
    /* When there is more than 1 objects, 
     * you need to adjust the offset of each RelocEntry
     */
    /* Your code here */
    uint64_t temp = 0;
	for(auto &obj : allObject){
        for(auto &re : obj.relocTable){
            re.offset += temp;
        }
        temp += obj.sections[".text"].size;
    }
    /* in PIE executables, user code starts at 0xe9 by .text section */
    /* in non-PIE executables, user code starts at 0xe6 by .text section */
    uint64_t userCodeStart = isPIE ? 0xe9 : 0xe6;
    uint64_t textOff = mergedObject.sections[".text"].off + userCodeStart;
    uint64_t textAddr = mergedObject.sections[".text"].addr + userCodeStart;
	for (auto& obj : allObject) {
        for (auto& reloc : obj.relocTable) { 
            // 步骤1：更新重定位偏移
            reloc.offset += textOff;
    
            // 步骤2：计算目标内存地址
            const uint64_t targetMemAddr = reinterpret_cast<uint64_t>(mergedObject.baseAddr) + reloc.offset;
    
            // 步骤3：根据重定位类型计算填充值
            uint32_t relocWriteValue;  
            const uint32_t symVal = reloc.sym->value;  
            const uint32_t relocAddend = reloc.addend; 
    
            switch (reloc.type) {  
                case R_X86_64_32: {  
                    relocWriteValue = symVal + relocAddend;
                    break;
                }
                case R_X86_64_PLT32:
                case R_X86_64_PC32: {
                    const uint32_t adjustedOffset = reloc.offset - textOff;  
                    const uint32_t baseAddrTerm = adjustedOffset + textAddr;  
                    relocWriteValue = symVal - baseAddrTerm + relocAddend;
                    break;
                }
            }
    
            // 步骤4：写入目标内存
            *(uint32_t*)targetMemAddr = relocWriteValue;  
        }
    }
}
